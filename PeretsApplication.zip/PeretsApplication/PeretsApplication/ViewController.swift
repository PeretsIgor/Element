import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var buttonServices: UIButton!
    @IBOutlet weak var buttonPortfolio: UIButton!
    @IBOutlet weak var buttonAboutUs: UIButton!
    @IBOutlet weak var buttonContactUs: UIButton!
    @IBOutlet weak var buttonSocialLinks: UIButton!
    
    let cornerRadius = 5
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        buttonServices.layer.cornerRadius = CGFloat(cornerRadius)
        buttonPortfolio.layer.cornerRadius = CGFloat(cornerRadius)
        buttonAboutUs.layer.cornerRadius = CGFloat(cornerRadius)
        buttonContactUs.layer.cornerRadius = CGFloat(cornerRadius)
        buttonSocialLinks.layer.cornerRadius = CGFloat(cornerRadius)
 
        
        
        
    }

    
    @IBAction func services(_ sender: Any) {
        
        self.tabBarController?.selectedIndex = 2
    }
    
    @IBAction func portfolio(_ sender: Any) {
        
        self.tabBarController?.selectedIndex = 3
    }
    
    @IBAction func aboutUs(_ sender: Any) {
        
        self.tabBarController?.selectedIndex = 1
    }
    
    @IBAction func contactUs(_ sender: Any) {
        
        self.tabBarController?.selectedIndex = 4
    }
    
   /* @IBAction func socialLinks(_ sender: Any) {
        
        
    }*/
    
}

