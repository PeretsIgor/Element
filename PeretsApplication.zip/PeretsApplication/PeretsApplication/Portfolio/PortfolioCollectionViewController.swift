//
//  PortfolioCollectionViewController.swift
//  PeretsApplication
//
import UIKit


private let reuseIdentifier = "Cell"

class PortfolioCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    var imageList = ["ArteVeneziano_1", "ArteVeneziano_2", "ArteVeneziano_3", "ArteVeneziano_4", "ArteVeneziano_5", "ArteVeneziano_6", "ArteVeneziano_7", "Enigma_1", "Matera_1", "Matera_2", "Matera_4", "Matera_5", "Matera1", "Matera2", "Mistero_1", "Mistero_2", "Mistero_3", "Palatino_1", "Palatino_2", "Palatino_3", "Palatino_4", "Palatino_5", "Palatino_6", "Palatino_8", "Palatino_9", "SabbiaPerlata_1", "Velluto_2", "Velluto", "ViaLattea_1", "ViaLattea_2", "ViaLattea_3", "ViaLattea_4"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView?.backgroundView = UIImageView(image: UIImage(named: "Background"))

    }


    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return imageList.count
    }

    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! PortfolioCollectionViewCell
    
        cell.cellImage.image = UIImage(named: imageList[indexPath.row])
    
        return cell
    }

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let screenSize : CGRect = UIScreen.main.bounds
        
        var widthCell = 0
        var heightCell = 0
        
        if screenSize.width == 320 {
            
             widthCell = 130
             heightCell = 130
        }
        
        if screenSize.width == 375 {
            
            widthCell = 160
            heightCell = 160
        }
        
        if screenSize.width == 414 {
            
            widthCell = 180
            heightCell = 180
        }
        
        if screenSize.width == 768 {
            
            widthCell = 230
            heightCell = 230
        }
        
        if screenSize.width == 834 {
            
            widthCell = 250
            heightCell = 250
        }
        
        if screenSize.width == 1024 {
            
            widthCell = 310
            heightCell = 310
        }
        
        return CGSize(width: widthCell, height: heightCell)
    }
    
}
