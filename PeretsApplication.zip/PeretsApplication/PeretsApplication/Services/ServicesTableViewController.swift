import UIKit


class ServicesTableViewController: UITableViewController {

    var titleList = ["Sabia Perlata", "Velluto", "Enigma", "Via Lattea", "Matera", "Palatino", "Mistero", "Arte Veneziano", "Antico Murano", "Fondo di Quarzo", "Cera Decorativa", "Cera Lavabile", "Lacca Esterna", "Lacca Protettiva satin", "Lacca Protettiva mat"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.backgroundView = UIImageView(image: UIImage(named: "Background"))
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "" , style: .plain, target: nil, action: nil)
    }


    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleList.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! ServicesTableViewCell

        cell.cellTitle.text = titleList[indexPath.row]

        return cell
    }

    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "showDetail") {
            
            let dvc = segue.destination as! ServicesViewController
            
            if let indexPath = self.tableView.indexPathForSelectedRow {
                
                dvc.sentData = titleList[indexPath.row] as String
            }
        }
    }
    

}
