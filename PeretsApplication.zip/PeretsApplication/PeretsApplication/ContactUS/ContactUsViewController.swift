import UIKit
import MapKit


class ContactUsViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var buttonDirections: UIButton!
    @IBOutlet weak var buttonCallUs: UIButton!
    @IBOutlet weak var buttonEmailUs: UIButton!
    @IBOutlet weak var buttonSocialLinks: UIButton!
    
    let cornerRadius = 5
    
    var latitudeInter = 49.93768743
    var longitudeInter = 36.29168272
    var latitudeSlon = 50.01059356
    var longitudeSlon = 36.21697783
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        buttonDirections.layer.cornerRadius = CGFloat(cornerRadius)
        buttonCallUs.layer.cornerRadius = CGFloat(cornerRadius)
        buttonEmailUs.layer.cornerRadius = CGFloat(cornerRadius)
        buttonSocialLinks.layer.cornerRadius = CGFloat(cornerRadius)
        
        let span = MKCoordinateSpanMake(0.2, 0.2)
        let span2 = MKCoordinateSpanMake(0.2, 0.2)
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: latitudeInter, longitude: longitudeInter), span: span)
        let region2 = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: latitudeSlon, longitude: longitudeSlon), span: span2)
        
        mapView.setRegion(region, animated: true)
        mapView.setRegion(region2, animated: true)
        
        
        let pinLocationInter: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitudeInter, longitudeInter)
        let pinLocationSlon: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitudeSlon, longitudeSlon)
        
        let pinAnnotationInter = MKPointAnnotation()
        pinAnnotationInter.coordinate = pinLocationInter
        pinAnnotationInter.title = "Будмен Інтер"
        pinAnnotationInter.subtitle = "Україна, Харків, пр.Льва Ландао 2/2"
        
        let pinAnnotationSlon = MKPointAnnotation()
        pinAnnotationSlon.coordinate = pinLocationSlon
        pinAnnotationSlon.title = "Будмен"
        pinAnnotationSlon.subtitle = "Україна, Харків, вул.Клочківська 119А"
        
        self.mapView.addAnnotation(pinAnnotationInter)
        self.mapView.addAnnotation(pinAnnotationSlon)
    }


    @IBAction func actionDirections(_ sender: Any) {
        
        
       UIApplication.shared.open(URL(string:"http://maps.apple.com/maps?daddr=\(latitudeInter),\(longitudeInter)")!, options: [:], completionHandler: nil)
        
       UIApplication.shared.open(URL(string:"http://maps.apple.com/maps?daddr=\(latitudeSlon),\(longitudeSlon)")!, options: [:], completionHandler: nil)
        
    }
    

    @IBAction func actionCallUs(_ sender: Any) {
        
        UIApplication.shared.open(URL(string:"tel://0501340444")!, options: [:], completionHandler: nil)
    }
    
}
